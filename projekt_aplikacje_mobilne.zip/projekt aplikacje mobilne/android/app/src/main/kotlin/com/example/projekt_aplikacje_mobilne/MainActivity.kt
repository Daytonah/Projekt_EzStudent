package com.example.projekt_aplikacje_mobilne

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
